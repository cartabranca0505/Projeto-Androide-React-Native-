package com.example.controledevendas3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.controledevendas3.ui.theme.CONTROLEDEVENDAS3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CONTROLEDEVENDAS3Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    CONTROLEDEVENDAS3Theme {
        Greeting("Android")
    }
    import React, { useState } from 'react';
    import { View, Text, TextInput, Button, Alert, FlatList, NativeModules } from 'react-native';
    import AsyncStorage from '@react-native-async-storage/async-storage';
    import { NavigationContainer } from '@react-navigation/native';
    import { createStackNavigator } from '@react-navigation/stack';

// Acesso ao módulo nativo Kotlin
    const { MyNativeModule } = NativeModules;

// Tela de Login
    const LoginScreen = ({ navigation }) => {
        const [email, setEmail] = useState('');
        const [password, setPassword] = useState('');

        const handleLogin = async () => {
        const user = await AsyncStorage.getItem(email);
        const parsedUser = JSON.parse(user);

        if (parsedUser && parsedUser.password === password) {
            await AsyncStorage.setItem('userToken', 'abc');
            navigation.navigate('Home');
        } else {
            Alert.alert('Erro', 'Usuário ou senha incorretos');
        }
    };

        return (
        <View style={{ padding: 20 }}>
        <Text>Email:</Text>
        <TextInput value={email} onChangeText={setEmail} />
        <Text>Senha:</Text>
        <TextInput value={password} onChangeText={setPassword} secureTextEntry />
        <Button title="Entrar" onPress={handleLogin} />
        <Button title="Criar Conta" onPress={() => navigation.navigate('Signup')} />
        <Button
        title="Say Hello from Kotlin"
        onPress={() => {
            MyNativeModule.sayHello('React Native', greeting => {
                Alert.alert('Greeting', greeting);
            });
        }}
        />
        </View>
        );
    };

// Tela de Registro
    const SignupScreen = ({ navigation }) => {
        const [email, setEmail] = useState('');
        const [password, setPassword] = useState('');

        const handleSignup = async () => {
        if (email && password) {
            const user = { email, password };
            await AsyncStorage.setItem(email, JSON.stringify(user));
            Alert.alert('Sucesso', 'Conta criada com sucesso');
            navigation.navigate('Login');
        } else {
            Alert.alert('Erro', 'Preencha todos os campos');
        }
    };

        return (
        <View style={{ padding: 20 }}>
        <Text>Email:</Text>
        <TextInput value={email} onChangeText={setEmail} />
        <Text>Senha:</Text>
        <TextInput value={password} onChangeText={setPassword} secureTextEntry />
        <Button title="Criar Conta" onPress={handleSignup} />
        </View>
        );
    };

// Tela de Controle de Vendas
    const HomeScreen = () => {
        const [item, setItem] = useState('');
        const [quantity, setQuantity] = useState('');
        const [sales, setSales] = useState([]);

        const handleAddSale = () => {
        if (item && quantity) {
            setSales([...sales, { item, quantity }]);
            setItem('');
            setQuantity('');
        }
    };

        return (
        <View style={{ padding: 20 }}>
        <Text>Item:</Text>
        <TextInput value={item} onChangeText={setItem} />
        <Text>Quantidade:</Text>
        <TextInput value={quantity} onChangeText={setQuantity} keyboardType="numeric" />
        <Button title="Adicionar Venda" onPress={handleAddSale} />
        <FlatList
        data={sales}
        renderItem={({ item }) => (
            <View style={{ padding: 10 }}>
            <Text>{item.item}: {item.quantity}</Text>
            </View>
            )}
        keyExtractor={(item, index) => index.toString()}
        />
        </View>
        );
    };

// Tela de Baixa de Estoque
    const StockScreen = () => {
        const [item, setItem] = useState('');
        const [quantity, setQuantity] = useState('');
        const [stock, setStock] = useState([]);

        const handleDecreaseStock = () => {
        if (item && quantity) {
            setStock([...stock, { item, quantity }]);
            setItem('');
            setQuantity('');
        }
    };

        return (
        <View style={{ padding: 20 }}>
        <Text>Item:</Text>
        <TextInput value={item} onChangeText={setItem} />
        <Text>Quantidade:</Text>
        <TextInput value={quantity} onChangeText={setQuantity} keyboardType="numeric" />
        <Button title="Baixar Estoque" onPress={handleDecreaseStock} />
        <FlatList
        data={stock}
        renderItem={({ item }) => (
            <View style={{ padding: 10 }}>
            <Text>{item.item}: {item.quantity}</Text>
            </View>
            )}
        keyExtractor={(item, index) => index.toString()}
        />
        </View>
        );
    };

// Configuração de Navegação
    const Stack = createStackNavigator();

    const App = () => {
        return (
        <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Signup" component={SignupScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Stock" component={StockScreen} />
        </Stack.Navigator>
        </NavigationContainer>
        );
    };

    export default App;

}